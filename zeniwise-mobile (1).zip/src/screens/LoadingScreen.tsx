"use client"

import type React from "react"
import { useEffect } from "react"
import { View, Text, Animated } from "react-native"
import { useAuth } from "../context/AuthContext"

export const LoadingScreen: React.FC = () => {
  const { user } = useAuth()
  const scaleAnim = new Animated.Value(0.8)

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(scaleAnim, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 0.8,
          duration: 1000,
          useNativeDriver: true,
        }),
      ]),
    ).start()
  }, [])

  return (
    <View className="flex-1 bg-background justify-center items-center">
      <Animated.Text style={{ transform: [{ scale: scaleAnim }] }} className="text-6xl mb-4">
        🌱
      </Animated.Text>
      <Text className="text-white text-2xl font-bold">Zeniwise</Text>
      <Text className="text-gray-400 text-sm mt-2">Smart Budget Planning</Text>
    </View>
  )
}
