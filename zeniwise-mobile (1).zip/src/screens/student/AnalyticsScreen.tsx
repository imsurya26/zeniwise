import type React from "react"
import { View, Text, ScrollView, TouchableOpacity, Alert, Share } from "react-native"
import { PieChart, BarChart } from "react-native-chart-kit"
import { Dimensions } from "react-native"

const screenWidth = Dimensions.get("window").width

const PIE_DATA = [
  { name: "Food", population: 35, color: "#EF4444", legendFontColor: "#fff" },
  {
    name: "Transport",
    population: 20,
    color: "#FACC15",
    legendFontColor: "#fff",
  },
  {
    name: "Entertainment",
    population: 18,
    color: "#3B82F6",
    legendFontColor: "#fff",
  },
  {
    name: "Shopping",
    population: 15,
    color: "#EC4899",
    legendFontColor: "#fff",
  },
  {
    name: "Other",
    population: 12,
    color: "#8B5CF6",
    legendFontColor: "#fff",
  },
]

const BAR_DATA = {
  labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
  datasets: [
    {
      data: [32, 45, 28, 80, 99, 65, 50],
      color: (opacity = 1) => `rgba(22, 163, 74, ${opacity})`,
      strokeWidth: 2,
    },
  ],
}

const EXPENSE_DATA = [
  { date: "2024-01-15", category: "Food", amount: 12.5, description: "Lunch" },
  { date: "2024-01-15", category: "Transport", amount: 5.0, description: "Bus fare" },
  { date: "2024-01-16", category: "Entertainment", amount: 15.0, description: "Movie" },
  { date: "2024-01-16", category: "Food", amount: 8.75, description: "Coffee" },
  { date: "2024-01-17", category: "Shopping", amount: 45.0, description: "Books" },
  { date: "2024-01-17", category: "Food", amount: 22.5, description: "Dinner" },
  { date: "2024-01-18", category: "Transport", amount: 10.0, description: "Uber" },
  { date: "2024-01-18", category: "Entertainment", amount: 20.0, description: "Concert" },
  { date: "2024-01-19", category: "Food", amount: 18.0, description: "Brunch" },
  { date: "2024-01-19", category: "Other", amount: 7.5, description: "Supplies" },
]

const generateCSV = (): string => {
  const headers = ["Date", "Category", "Amount", "Description"]
  const rows = EXPENSE_DATA.map((expense) => [
    expense.date,
    expense.category,
    `$${expense.amount.toFixed(2)}`,
    expense.description,
  ])

  const csvContent = [
    headers.join(","),
    ...rows.map((row) => row.join(",")),
    "",
    "Summary",
    `Total Expenses,$${EXPENSE_DATA.reduce((sum, e) => sum + e.amount, 0).toFixed(2)}`,
    `Average Daily,$${(EXPENSE_DATA.reduce((sum, e) => sum + e.amount, 0) / 7).toFixed(2)}`,
  ].join("\n")

  return csvContent
}

const handleExportCSV = async () => {
  try {
    const csvContent = generateCSV()
    const fileName = `zeniwise-expenses-${new Date().toISOString().split("T")[0]}.csv`

    await Share.share({
      message: csvContent,
      title: "Export Expenses",
      url: `data:text/csv;base64,${Buffer.from(csvContent).toString("base64")}`,
    })
  } catch (error) {
    Alert.alert("Export Failed", "Unable to export CSV file")
  }
}

export const AnalyticsScreen: React.FC = () => {
  const totalSpent = EXPENSE_DATA.reduce((sum, e) => sum + e.amount, 0)
  const averageDaily = (totalSpent / 7).toFixed(2)
  const highestCategory = "Food"

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="px-4 py-6">
        {/* Header */}
        <View className="mb-6">
          <Text className="text-white text-2xl font-bold">Analytics</Text>
          <Text className="text-gray-400 text-sm mt-1">This month's spending breakdown</Text>
        </View>

        {/* Pie Chart */}
        <View className="bg-dark-800 rounded-lg p-4 mb-6 border border-dark-700">
          <Text className="text-white font-bold mb-4">Spending by Category</Text>
          <PieChart
            data={PIE_DATA}
            width={screenWidth - 48}
            height={220}
            chartConfig={{
              backgroundColor: "#0E1B14",
              backgroundGradientFrom: "#0E1B14",
              backgroundGradientTo: "#0E1B14",
              color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
            }}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="15"
            absolute
          />
        </View>

        {/* Bar Chart */}
        <View className="bg-dark-800 rounded-lg p-4 mb-6 border border-dark-700">
          <Text className="text-white font-bold mb-4">Daily Spending</Text>
          <BarChart
            data={BAR_DATA}
            width={screenWidth - 48}
            height={220}
            chartConfig={{
              backgroundColor: "#0E1B14",
              backgroundGradientFrom: "#0E1B14",
              backgroundGradientTo: "#0E1B14",
              color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(107, 114, 128, ${opacity})`,
              barPercentage: 0.7,
            }}
            verticalLabelRotation={0}
          />
        </View>

        {/* Export Button */}
        <TouchableOpacity
          onPress={handleExportCSV}
          className="bg-primary py-4 rounded-lg flex-row justify-center items-center mb-6 active:opacity-80"
        >
          <Text className="text-xl mr-2">📥</Text>
          <Text className="text-white font-bold text-base">Export as CSV</Text>
        </TouchableOpacity>

        {/* Summary Stats */}
        <View className="gap-3 mb-6">
          <View className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between">
            <Text className="text-gray-400">Average Daily Spend</Text>
            <Text className="text-white font-bold">${averageDaily}</Text>
          </View>
          <View className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between">
            <Text className="text-gray-400">Highest Category</Text>
            <Text className="text-white font-bold">{highestCategory} (35%)</Text>
          </View>
          <View className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between">
            <Text className="text-gray-400">Month Total</Text>
            <Text className="text-white font-bold">${totalSpent.toFixed(2)}</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  )
}
