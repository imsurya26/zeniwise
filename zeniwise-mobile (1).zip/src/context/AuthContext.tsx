"use client"

import type React from "react"
import { createContext, useState, useContext } from "react"
import type { User, UserRole } from "../types"

interface AuthContextType {
  user: User | null
  role: UserRole | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  switchRole: (role: UserRole) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [role, setRole] = useState<UserRole | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const login = async (email: string, password: string) => {
    setIsLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))
    const newUser: User = {
      id: "1",
      name: "Alex Student",
      email,
      role: "student",
      avatar: "👤",
    }
    setUser(newUser)
    setRole("student")
    setIsLoading(false)
  }

  const logout = () => {
    setUser(null)
    setRole(null)
  }

  const switchRole = (newRole: UserRole) => {
    setRole(newRole)
  }

  return (
    <AuthContext.Provider value={{ user, role, isLoading, login, logout, switchRole }}>{children}</AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider")
  }
  return context
}
