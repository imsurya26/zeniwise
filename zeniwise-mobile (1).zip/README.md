# Zeniwise - AI-Powered Student Budget Planner

A comprehensive React Native mobile app for students to manage their finances with AI-powered insights, parental co-pilot mode, and gamified savings goals.

## Features

### Student Features
- **Home Tab**: Daily expense tracking, OCR receipt upload, rotating tips
- **Savings Tab**: Goal tracker with progress bars and milestones
- **Rewards Tab**: Badge system with eco-saving streak tracker
- **Analytics Tab**: Pie charts, bar graphs, and CSV export
- **Profile Tab**: Account management, statements, and settings

### Parent Features
- **Overview Tab**: Family budget overview, linked student accounts, emergency funds
- **Alerts Tab**: Real-time notifications for spending, goals, and milestones
- **Settings Tab**: Notification preferences and account management

## Tech Stack

- **Framework**: React Native with Expo
- **Navigation**: React Navigation v7
- **Styling**: NativeWind (Tailwind CSS for React Native)
- **Charts**: react-native-chart-kit
- **Animations**: Expo Linear Gradient, React Native Reanimated
- **State Management**: React Context API

## Installation

### Prerequisites
- Node.js 16+ and npm/yarn
- Expo CLI: `npm install -g expo-cli`
- iOS Simulator (Mac) or Android Emulator

### Setup Steps

1. **Clone or extract the project**
   \`\`\`bash
   cd zeniwise
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   npm install
   # or
   yarn install
   \`\`\`

3. **Start the development server**
   \`\`\`bash
   npm start
   # or
   expo start
   \`\`\`

4. **Run on simulator/device**
   - Press `i` for iOS Simulator
   - Press `a` for Android Emulator
   - Scan QR code with Expo Go app on physical device

## Project Structure

\`\`\`
zeniwise/
├── App.tsx                 # Entry point
├── app.json               # Expo configuration
├── src/
│   ├── context/
│   │   └── AuthContext.tsx        # Auth state management
│   ├── navigation/
│   │   ├── RootNavigator.tsx      # Main navigation router
│   │   ├── StudentNavigator.tsx   # Student tab navigation
│   │   └── ParentNavigator.tsx    # Parent tab navigation
│   ├── screens/
│   │   ├── LoadingScreen.tsx      # Splash/loading animation
│   │   ├── LoginScreen.tsx        # Authentication
│   │   ├── student/
│   │   │   ├── HomeScreen.tsx
│   │   │   ├── SavingsScreen.tsx
│   │   │   ├── RewardsScreen.tsx
│   │   │   ├── AnalyticsScreen.tsx
│   │   │   └── ProfileScreen.tsx
│   │   └── parent/
│   │       ├── ParentDashboardScreen.tsx
│   │       ├── ParentAlertsScreen.tsx
│   │       └── ParentSettingsScreen.tsx
│   └── types/
│       └── index.ts               # TypeScript interfaces
├── styles/
│   └── globals.css               # Global styles
├── tailwind.config.js            # Tailwind configuration
└── tsconfig.json                 # TypeScript configuration
\`\`\`

## Color Theme

- **Primary**: #16A34A (Green)
- **Background**: #0E1B14 (Dark)
- **Warning**: #FACC15 (Yellow)
- **Parent Mode**: #FDF6E3 (Light Cream)
- **Dark Variants**: #1F2937, #111827, #374151

## Authentication Flow

1. **Loading Screen**: 2-second splash animation with Zeniwise logo
2. **Login Screen**: Email/password or Google sign-in
3. **Role Selection**: Automatically routes to student or parent dashboard
4. **Tab Navigation**: Role-specific bottom tab navigation

## Key Components

### AuthContext
Manages user authentication state and role switching:
- `user`: Current user object
- `role`: "student" or "parent"
- `login()`: Authenticate user
- `logout()`: Clear session
- `switchRole()`: Change between roles

### Navigation Structure
- **RootNavigator**: Handles auth flow and role-based routing
- **StudentNavigator**: 5-tab bottom navigation for students
- **ParentNavigator**: 3-tab bottom navigation for parents

## Sample Data

All screens include sample data for demonstration:
- Expenses with categories and icons
- Savings goals with progress tracking
- Achievement badges with unlock progress
- Parent alerts with timestamps
- Monthly statements

## Customization

### Change Colors
Edit `tailwind.config.js` theme colors:
\`\`\`javascript
colors: {
  primary: "#16A34A",
  background: "#0E1B14",
  warning: "#FACC15",
}
\`\`\`

### Add New Screens
1. Create screen file in `src/screens/`
2. Add to appropriate navigator
3. Import and register in navigation file

### Modify Sample Data
Edit the `SAMPLE_*` constants in each screen file to customize data.

## Development Tips

- Use `console.log()` for debugging
- Hot reload works with Expo - save files to auto-refresh
- Use React DevTools with Expo for component inspection
- Test on both iOS and Android for platform-specific issues

## Future Enhancements

- Backend API integration for real data
- Google Sign-In implementation
- OCR receipt scanning with ML Kit
- Push notifications
- Data persistence with AsyncStorage
- Real-time budget alerts
- Social features and challenges

## License

MIT

## Support

For issues or questions, please refer to:
- [React Navigation Docs](https://reactnavigation.org/)
- [Expo Documentation](https://docs.expo.dev/)
- [NativeWind Docs](https://www.nativewind.dev/)
