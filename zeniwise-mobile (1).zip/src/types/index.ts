export type UserRole = "student" | "parent"

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  avatar?: string
  linkedAccounts?: string[]
}

export interface Expense {
  id: string
  category: string
  amount: number
  description: string
  date: string
  receipt?: string
  shared?: boolean
}

export interface SavingsGoal {
  id: string
  title: string
  targetAmount: number
  currentAmount: number
  deadline: string
  icon: string
}

export interface Badge {
  id: string
  title: string
  description: string
  icon: string
  unlocked: boolean
  progress: number
}

export interface Alert {
  id: string
  type: "warning" | "success" | "info"
  title: string
  message: string
  timestamp: string
}
