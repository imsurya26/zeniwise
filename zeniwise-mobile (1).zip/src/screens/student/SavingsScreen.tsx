import type React from "react"
import { View, Text, ScrollView, FlatList } from "react-native"
import { LinearGradient } from "expo-linear-gradient"

interface Goal {
  id: string
  title: string
  targetAmount: number
  currentAmount: number
  icon: string
}

const SAMPLE_GOALS: Goal[] = [
  {
    id: "1",
    title: "Gaming Laptop",
    targetAmount: 1500,
    currentAmount: 750,
    icon: "💻",
  },
  {
    id: "2",
    title: "Summer Trip",
    targetAmount: 800,
    currentAmount: 320,
    icon: "✈️",
  },
  {
    id: "3",
    title: "New Headphones",
    targetAmount: 200,
    currentAmount: 180,
    icon: "🎧",
  },
]

export const SavingsScreen: React.FC = () => {
  const totalSaved = SAMPLE_GOALS.reduce((sum, g) => sum + g.currentAmount, 0)
  const totalTarget = SAMPLE_GOALS.reduce((sum, g) => sum + g.targetAmount, 0)

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="px-4 py-6">
        {/* Header Stats */}
        <View className="mb-6">
          <Text className="text-gray-400 text-sm">Total Saved</Text>
          <Text className="text-white text-4xl font-bold">${totalSaved.toFixed(2)}</Text>
          <Text className="text-gray-400 text-xs mt-1">of ${totalTarget.toFixed(2)} target</Text>
        </View>

        {/* Goals List */}
        <FlatList
          scrollEnabled={false}
          data={SAMPLE_GOALS}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => {
            const progress = (item.currentAmount / item.targetAmount) * 100
            return (
              <LinearGradient
                colors={["#1F2937", "#111827"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                className="rounded-lg p-4 mb-4 border border-dark-700"
              >
                <View className="flex-row justify-between items-start mb-3">
                  <View className="flex-row items-center flex-1">
                    <Text className="text-3xl mr-3">{item.icon}</Text>
                    <View className="flex-1">
                      <Text className="text-white font-bold">{item.title}</Text>
                      <Text className="text-gray-400 text-xs">
                        ${item.currentAmount.toFixed(2)} / ${item.targetAmount.toFixed(2)}
                      </Text>
                    </View>
                  </View>
                </View>

                {/* Progress Bar */}
                <View className="bg-dark-900 rounded-full h-2 overflow-hidden">
                  <View className="bg-primary h-full" style={{ width: `${Math.min(progress, 100)}%` }} />
                </View>

                <Text className="text-primary text-xs mt-2 font-semibold">{progress.toFixed(0)}% Complete</Text>
              </LinearGradient>
            )
          }}
        />
      </View>
    </ScrollView>
  )
}
