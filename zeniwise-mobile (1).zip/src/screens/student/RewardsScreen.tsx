import type React from "react"
import { View, Text, ScrollView, FlatList, TouchableOpacity } from "react-native"
import { LinearGradient } from "expo-linear-gradient"

interface Badge {
  id: string
  title: string
  description: string
  icon: string
  unlocked: boolean
  progress: number
}

const SAMPLE_BADGES: Badge[] = [
  {
    id: "1",
    title: "Budget Master",
    description: "Stay under budget for 7 days",
    icon: "👑",
    unlocked: true,
    progress: 100,
  },
  {
    id: "2",
    title: "Eco Saver",
    description: "Save $50 this month",
    icon: "🌱",
    unlocked: true,
    progress: 100,
  },
  {
    id: "3",
    title: "Savings Champion",
    description: "Reach $500 in savings",
    icon: "🏆",
    unlocked: false,
    progress: 65,
  },
  {
    id: "4",
    title: "Consistent Tracker",
    description: "Log expenses for 30 days",
    icon: "📊",
    unlocked: false,
    progress: 45,
  },
  {
    id: "5",
    title: "Goal Achiever",
    description: "Complete 3 savings goals",
    icon: "🎯",
    unlocked: false,
    progress: 33,
  },
  {
    id: "6",
    title: "Eco Warrior",
    description: "Reduce spending by 20%",
    icon: "♻️",
    unlocked: false,
    progress: 55,
  },
]

export const RewardsScreen: React.FC = () => {
  const unlockedCount = SAMPLE_BADGES.filter((b) => b.unlocked).length

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="px-4 py-6">
        {/* Header */}
        <View className="mb-6">
          <Text className="text-gray-400 text-sm">Badges Unlocked</Text>
          <Text className="text-white text-4xl font-bold">
            {unlockedCount}/{SAMPLE_BADGES.length}
          </Text>
        </View>

        {/* Eco-Saving Tracker */}
        <LinearGradient
          colors={["#16A34A", "#15803D"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          className="rounded-lg p-4 mb-6 border border-green-600"
        >
          <View className="flex-row justify-between items-center">
            <View>
              <Text className="text-white font-bold text-lg">Eco-Saving Streak</Text>
              <Text className="text-green-100 text-sm mt-1">🌍 12 days of sustainable spending</Text>
            </View>
            <Text className="text-4xl">🔥</Text>
          </View>
        </LinearGradient>

        {/* Badges Grid */}
        <FlatList
          scrollEnabled={false}
          data={SAMPLE_BADGES}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={{ gap: 12 }}
          renderItem={({ item }) => (
            <TouchableOpacity className="flex-1" activeOpacity={0.7}>
              <LinearGradient
                colors={item.unlocked ? ["#1F2937", "#111827"] : ["#374151", "#1F2937"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                className={`rounded-lg p-4 border ${item.unlocked ? "border-primary" : "border-dark-700"}`}
              >
                <Text className="text-4xl mb-2 text-center">{item.icon}</Text>
                <Text className="text-white font-bold text-sm text-center">{item.title}</Text>
                <Text className="text-gray-400 text-xs text-center mt-1">{item.description}</Text>

                {!item.unlocked && (
                  <View className="mt-3">
                    <View className="bg-dark-900 rounded-full h-1.5 overflow-hidden">
                      <View className="bg-primary h-full" style={{ width: `${item.progress}%` }} />
                    </View>
                    <Text className="text-primary text-xs mt-1 text-center font-semibold">{item.progress}%</Text>
                  </View>
                )}
              </LinearGradient>
            </TouchableOpacity>
          )}
        />
      </View>
    </ScrollView>
  )
}
