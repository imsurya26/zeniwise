"use client"

import type React from "react"
import { useState } from "react"
import { View, Text, ScrollView, TouchableOpacity, FlatList } from "react-native"
import { LinearGradient } from "expo-linear-gradient"

interface Expense {
  id: string
  category: string
  amount: number
  description: string
  date: string
  icon: string
}

const SAMPLE_EXPENSES: Expense[] = [
  {
    id: "1",
    category: "Food",
    amount: 12.5,
    description: "Coffee & Lunch",
    date: "Today",
    icon: "🍕",
  },
  {
    id: "2",
    category: "Transport",
    amount: 5.0,
    description: "Bus fare",
    date: "Today",
    icon: "🚌",
  },
  {
    id: "3",
    category: "Entertainment",
    amount: 15.0,
    description: "Movie ticket",
    date: "Yesterday",
    icon: "🎬",
  },
]

const TIPS = [
  "💡 Pack lunch to save $5-10 daily!",
  "💡 Use student discounts whenever possible",
  "💡 Track your spending weekly for better insights",
  "💡 Set a daily budget and stick to it",
]

const CATEGORY_GRADIENTS: Record<string, [string, string]> = {
  Food: ["#DC2626", "#991B1B"],
  Transport: ["#2563EB", "#1E40AF"],
  Entertainment: ["#9333EA", "#6B21A8"],
  Shopping: ["#EC4899", "#BE185D"],
  Utilities: ["#0891B2", "#0E7490"],
  Health: ["#16A34A", "#15803D"],
}

export const HomeScreen: React.FC = () => {
  const [expenses, setExpenses] = useState(SAMPLE_EXPENSES)
  const [tipIndex, setTipIndex] = useState(0)

  const totalToday = expenses.filter((e) => e.date === "Today").reduce((sum, e) => sum + e.amount, 0)

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="px-4 py-6">
        {/* Header */}
        <View className="mb-6">
          <Text className="text-gray-400 text-sm">Today's Spending</Text>
          <Text className="text-white text-4xl font-bold">${totalToday.toFixed(2)}</Text>
        </View>

        {/* Quick Actions */}
        <View className="flex-row gap-3 mb-6">
          <TouchableOpacity className="flex-1 bg-primary py-3 rounded-lg flex-row justify-center items-center">
            <Text className="text-xl mr-2">➕</Text>
            <Text className="text-white font-semibold">Add Expense</Text>
          </TouchableOpacity>
          <TouchableOpacity className="flex-1 bg-dark-800 border border-primary/30 py-3 rounded-lg flex-row justify-center items-center hover:bg-dark-700">
            <Text className="text-2xl mr-2">📄</Text>
            <Text className="text-white font-semibold">OCR</Text>
          </TouchableOpacity>
        </View>

        {/* Tip of the Day */}
        <LinearGradient
          colors={["#1F2937", "#111827"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          className="rounded-lg p-4 mb-6 border border-dark-700"
        >
          <View className="flex-row justify-between items-start">
            <View className="flex-1">
              <Text className="text-warning font-bold mb-1">Tip of the Day</Text>
              <Text className="text-gray-300 text-sm">{TIPS[tipIndex]}</Text>
            </View>
            <TouchableOpacity onPress={() => setTipIndex((i) => (i + 1) % TIPS.length)} className="ml-2">
              <Text className="text-xl">🔄</Text>
            </TouchableOpacity>
          </View>
        </LinearGradient>

        {/* Expenses List */}
        <View className="mb-6">
          <Text className="text-white font-bold text-lg mb-3">Recent Expenses</Text>
          <FlatList
            scrollEnabled={false}
            data={expenses}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => {
              const [startColor, endColor] = CATEGORY_GRADIENTS[item.category] || ["#1F2937", "#111827"]

              return (
                <LinearGradient
                  colors={[startColor, endColor]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  className="rounded-lg mb-3 overflow-hidden border border-dark-700/50"
                >
                  <View className="p-4 flex-row justify-between items-center">
                    <View className="flex-row items-center flex-1">
                      <Text className="text-3xl mr-3">{item.icon}</Text>
                      <View className="flex-1">
                        <Text className="text-white font-semibold">{item.category}</Text>
                        <Text className="text-gray-200 text-xs">{item.description}</Text>
                      </View>
                    </View>
                    <View className="items-end">
                      <Text className="text-white font-bold">-${item.amount.toFixed(2)}</Text>
                      <Text className="text-gray-100 text-xs">{item.date}</Text>
                    </View>
                  </View>
                </LinearGradient>
              )
            }}
          />
        </View>
      </View>
    </ScrollView>
  )
}
