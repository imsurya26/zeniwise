"use client"

import React from "react"
import { View, Text, ScrollView, TouchableOpacity, Switch } from "react-native"
import { useAuth } from "../../context/AuthContext"

export const ParentSettingsScreen: React.FC = () => {
  const { logout } = useAuth()
  const [notificationsEnabled, setNotificationsEnabled] = React.useState(true)
  const [budgetAlerts, setBudgetAlerts] = React.useState(true)

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="px-4 py-6">
        {/* Header */}
        <View className="mb-6">
          <Text className="text-white text-2xl font-bold">Settings</Text>
        </View>

        {/* Notifications */}
        <View className="mb-6">
          <Text className="text-white font-bold text-lg mb-3">Notifications</Text>
          <View className="gap-3">
            <View className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between items-center">
              <Text className="text-white">Enable Notifications</Text>
              <Switch
                value={notificationsEnabled}
                onValueChange={setNotificationsEnabled}
                trackColor={{ false: "#374151", true: "#16A34A" }}
              />
            </View>
            <View className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between items-center">
              <Text className="text-white">Budget Alerts</Text>
              <Switch
                value={budgetAlerts}
                onValueChange={setBudgetAlerts}
                trackColor={{ false: "#374151", true: "#16A34A" }}
              />
            </View>
          </View>
        </View>

        {/* Account */}
        <View className="mb-6">
          <Text className="text-white font-bold text-lg mb-3">Account</Text>
          <View className="gap-2">
            <TouchableOpacity className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between items-center">
              <Text className="text-white">Edit Profile</Text>
              <Text className="text-gray-400">→</Text>
            </TouchableOpacity>
            <TouchableOpacity className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between items-center">
              <Text className="text-white">Privacy Policy</Text>
              <Text className="text-gray-400">→</Text>
            </TouchableOpacity>
            <TouchableOpacity className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between items-center">
              <Text className="text-white">Terms of Service</Text>
              <Text className="text-gray-400">→</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Sign Out */}
        <TouchableOpacity
          onPress={logout}
          className="bg-red-900 border border-red-700 py-3 rounded-lg flex-row justify-center items-center"
        >
          <Text className="text-xl mr-2">🚪</Text>
          <Text className="text-white font-bold">Sign Out</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  )
}
