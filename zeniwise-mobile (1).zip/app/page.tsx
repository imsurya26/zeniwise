"use client"

import { RootNavigator } from "@/src/navigation/RootNavigator"
import { AuthProvider } from "@/src/context/AuthContext"

export default function Page() {
  return (
    <AuthProvider>
      <RootNavigator />
    </AuthProvider>
  )
}
