"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { NavigationContainer } from "@react-navigation/native"
import { createNativeStackNavigator } from "@react-navigation/stack"
import { LoadingScreen } from "../screens/LoadingScreen"
import { LoginScreen } from "../screens/LoginScreen"
import { StudentNavigator } from "./StudentNavigator"
import { ParentNavigator } from "./ParentNavigator"
import { useAuth } from "../context/AuthContext"

const Stack = createNativeStackNavigator()

export const RootNavigator: React.FC = () => {
  const { user, role, isLoading } = useAuth()
  const [appReady, setAppReady] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setAppReady(true), 2000)
    return () => clearTimeout(timer)
  }, [])

  if (!appReady || isLoading) {
    return <LoadingScreen />
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!user ? (
          <Stack.Screen name="Login" component={LoginScreen} />
        ) : role === "student" ? (
          <Stack.Screen name="StudentApp" component={StudentNavigator} />
        ) : (
          <Stack.Screen name="ParentApp" component={ParentNavigator} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  )
}
