import type React from "react"
import { View, Text, ScrollView, FlatList, TouchableOpacity } from "react-native"

interface Alert {
  id: string
  type: "warning" | "success" | "info"
  title: string
  message: string
  timestamp: string
  studentName: string
}

const SAMPLE_ALERTS: Alert[] = [
  {
    id: "1",
    type: "warning",
    title: "Budget Alert",
    message: "Alex has spent 85% of monthly budget",
    timestamp: "2 hours ago",
    studentName: "Alex",
  },
  {
    id: "2",
    type: "success",
    title: "Goal Achieved",
    message: "Jordan completed savings goal: Summer Trip",
    timestamp: "1 day ago",
    studentName: "Jordan",
  },
  {
    id: "3",
    type: "info",
    title: "New Expense",
    message: "Alex spent $45 on Entertainment",
    timestamp: "3 hours ago",
    studentName: "Alex",
  },
]

export const ParentAlertsScreen: React.FC = () => {
  const getAlertColor = (type: string) => {
    switch (type) {
      case "warning":
        return "#FACC15"
      case "success":
        return "#16A34A"
      case "info":
        return "#3B82F6"
      default:
        return "#6B7280"
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "warning":
        return "⚠️"
      case "success":
        return "✅"
      case "info":
        return "ℹ️"
      default:
        return "📌"
    }
  }

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="px-4 py-6">
        {/* Header */}
        <View className="mb-6">
          <Text className="text-white text-2xl font-bold">Alerts</Text>
          <Text className="text-gray-400 text-sm mt-1">{SAMPLE_ALERTS.length} recent notifications</Text>
        </View>

        {/* Alerts List */}
        <FlatList
          scrollEnabled={false}
          data={SAMPLE_ALERTS}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity className="bg-dark-800 rounded-lg p-4 mb-3 border border-dark-700">
              <View className="flex-row justify-between items-start">
                <View className="flex-row items-start flex-1">
                  <Text className="text-2xl mr-3">{getAlertIcon(item.type)}</Text>
                  <View className="flex-1">
                    <Text className="text-white font-bold">{item.title}</Text>
                    <Text className="text-gray-400 text-sm mt-1">{item.message}</Text>
                    <View className="flex-row justify-between items-center mt-2">
                      <Text className="text-gray-500 text-xs">{item.studentName}</Text>
                      <Text className="text-gray-500 text-xs">{item.timestamp}</Text>
                    </View>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
          )}
        />
      </View>
    </ScrollView>
  )
}
