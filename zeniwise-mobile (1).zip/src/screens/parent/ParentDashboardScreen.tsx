import type React from "react"
import { View, Text, ScrollView, FlatList, TouchableOpacity } from "react-native"
import { LinearGradient } from "expo-linear-gradient"

interface LinkedStudent {
  id: string
  name: string
  email: string
  monthlySpent: number
  monthlyBudget: number
  avatar: string
}

const LINKED_STUDENTS: LinkedStudent[] = [
  {
    id: "1",
    name: "Alex",
    email: "alex@email.com",
    monthlySpent: 450,
    monthlyBudget: 500,
    avatar: "👦",
  },
  {
    id: "2",
    name: "Jordan",
    email: "jordan@email.com",
    monthlySpent: 320,
    monthlyBudget: 400,
    avatar: "👧",
  },
]

export const ParentDashboardScreen: React.FC = () => {
  const totalSpent = LINKED_STUDENTS.reduce((sum, s) => sum + s.monthlySpent, 0)
  const totalBudget = LINKED_STUDENTS.reduce((sum, s) => sum + s.monthlyBudget, 0)

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="px-4 py-6">
        {/* Header */}
        <View className="mb-6">
          <Text className="text-gray-400 text-sm">Family Overview</Text>
          <Text className="text-white text-3xl font-bold">${totalSpent.toFixed(2)}</Text>
          <Text className="text-gray-400 text-xs mt-1">of ${totalBudget.toFixed(2)} budget</Text>
        </View>

        {/* Budget Overview */}
        <LinearGradient
          colors={["#1F2937", "#111827"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          className="rounded-lg p-4 mb-6 border border-dark-700"
        >
          <View className="bg-dark-900 rounded-full h-3 overflow-hidden mb-3">
            <View className="bg-primary h-full" style={{ width: `${(totalSpent / totalBudget) * 100}%` }} />
          </View>
          <View className="flex-row justify-between">
            <Text className="text-gray-400 text-xs">{((totalSpent / totalBudget) * 100).toFixed(0)}% Used</Text>
            <Text className="text-gray-400 text-xs">${(totalBudget - totalSpent).toFixed(2)} Remaining</Text>
          </View>
        </LinearGradient>

        {/* Linked Students */}
        <Text className="text-white font-bold text-lg mb-3">Linked Accounts</Text>
        <FlatList
          scrollEnabled={false}
          data={LINKED_STUDENTS}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => {
            const progress = (item.monthlySpent / item.monthlyBudget) * 100
            return (
              <TouchableOpacity className="bg-dark-800 rounded-lg p-4 mb-3 border border-dark-700">
                <View className="flex-row justify-between items-start mb-3">
                  <View className="flex-row items-center flex-1">
                    <Text className="text-3xl mr-3">{item.avatar}</Text>
                    <View className="flex-1">
                      <Text className="text-white font-bold">{item.name}</Text>
                      <Text className="text-gray-400 text-xs">{item.email}</Text>
                    </View>
                  </View>
                  <View className="items-end">
                    <Text className="text-white font-bold">${item.monthlySpent.toFixed(2)}</Text>
                    <Text className="text-gray-400 text-xs">of ${item.monthlyBudget}</Text>
                  </View>
                </View>

                <View className="bg-dark-900 rounded-full h-2 overflow-hidden">
                  <View
                    className={`h-full ${progress > 80 ? "bg-red-500" : "bg-primary"}`}
                    style={{ width: `${Math.min(progress, 100)}%` }}
                  />
                </View>
              </TouchableOpacity>
            )
          }}
        />

        {/* Quick Actions */}
        <View className="gap-3 mt-6">
          <TouchableOpacity className="bg-primary py-3 rounded-lg flex-row justify-center items-center">
            <Text className="text-xl mr-2">💰</Text>
            <Text className="text-white font-bold">Send Emergency Funds</Text>
          </TouchableOpacity>
          <TouchableOpacity className="bg-dark-800 border border-dark-700 py-3 rounded-lg flex-row justify-center items-center">
            <Text className="text-xl mr-2">🎁</Text>
            <Text className="text-white font-bold">Award Milestone Rewards</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  )
}
