"use client"

import type React from "react"
import { View, Text, ScrollView, TouchableOpacity, FlatList } from "react-native"
import { LinearGradient } from "expo-linear-gradient"
import { useAuth } from "../../context/AuthContext"
import { useNavigation } from "@react-navigation/native"
import type { NativeStackNavigationProp } from "@react-navigation/native-stack"

interface Statement {
  id: string
  month: string
  total: number
  date: string
}

type ProfileScreenNavigationProp = NativeStackNavigationProp<any>

const SAMPLE_STATEMENTS: Statement[] = [
  { id: "1", month: "October 2024", total: 1245.5, date: "Oct 31" },
  { id: "2", month: "September 2024", total: 1089.2, date: "Sep 30" },
  { id: "3", month: "August 2024", total: 956.75, date: "Aug 31" },
]

export const ProfileScreen: React.FC = () => {
  const { user, logout } = useAuth()
  const navigation = useNavigation<ProfileScreenNavigationProp>()

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="px-4 py-6">
        {/* Profile Header */}
        <LinearGradient
          colors={["#1F2937", "#111827"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          className="rounded-lg p-6 mb-6 border border-dark-700 items-center"
        >
          <Text className="text-6xl mb-4">👤</Text>
          <Text className="text-white text-2xl font-bold">{user?.name}</Text>
          <Text className="text-gray-400 text-sm mt-1">{user?.email}</Text>
          <TouchableOpacity className="bg-primary mt-4 px-6 py-2 rounded-lg">
            <Text className="text-white font-semibold text-sm">Edit Profile</Text>
          </TouchableOpacity>
        </LinearGradient>

        {/* Account Settings */}
        <View className="mb-6">
          <Text className="text-white font-bold text-lg mb-3">Account</Text>
          <View className="gap-2">
            <TouchableOpacity className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between items-center">
              <Text className="text-white">Change Password</Text>
              <Text className="text-gray-400">→</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => navigation.navigate("PrivacySettings")}
              className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between items-center"
            >
              <Text className="text-white">Privacy Settings</Text>
              <Text className="text-gray-400">→</Text>
            </TouchableOpacity>
            <TouchableOpacity className="bg-dark-800 rounded-lg p-4 border border-dark-700 flex-row justify-between items-center">
              <Text className="text-white">Notifications</Text>
              <Text className="text-gray-400">→</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Statements */}
        <View className="mb-6">
          <Text className="text-white font-bold text-lg mb-3">Statements</Text>
          <FlatList
            scrollEnabled={false}
            data={SAMPLE_STATEMENTS}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <TouchableOpacity className="bg-dark-800 rounded-lg p-4 mb-2 border border-dark-700 flex-row justify-between items-center">
                <View>
                  <Text className="text-white font-semibold">{item.month}</Text>
                  <Text className="text-gray-400 text-xs">{item.date}</Text>
                </View>
                <View className="items-end">
                  <Text className="text-white font-bold">${item.total.toFixed(2)}</Text>
                  <Text className="text-primary text-xs">📥 Download</Text>
                </View>
              </TouchableOpacity>
            )}
          />
        </View>

        {/* Sign Out */}
        <TouchableOpacity
          onPress={logout}
          className="bg-red-900 border border-red-700 py-3 rounded-lg flex-row justify-center items-center"
        >
          <Text className="text-xl mr-2">🚪</Text>
          <Text className="text-white font-bold">Sign Out</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  )
}
