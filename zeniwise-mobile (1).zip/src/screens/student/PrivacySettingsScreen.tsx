"use client"

import type React from "react"
import { useState } from "react"
import { View, Text, ScrollView, TouchableOpacity, Switch, FlatList } from "react-native"
import { LinearGradient } from "expo-linear-gradient"
import { BlurView } from "expo-blur"

interface CategoryShare {
  id: string
  category: string
  icon: string
  shared: boolean
  description: string
}

const CATEGORIES: CategoryShare[] = [
  { id: "1", category: "Food", icon: "🍕", shared: true, description: "Meals & dining" },
  { id: "2", category: "Transport", icon: "🚌", shared: true, description: "Travel & commute" },
  { id: "3", category: "Entertainment", icon: "🎬", shared: false, description: "Movies & events" },
  { id: "4", category: "Shopping", icon: "🛍️", shared: false, description: "Clothes & items" },
  { id: "5", category: "Utilities", icon: "💡", shared: true, description: "Bills & subscriptions" },
  { id: "6", category: "Health", icon: "⚕️", shared: false, description: "Medical & wellness" },
]

export const PrivacySettingsScreen: React.FC = () => {
  const [categories, setCategories] = useState(CATEGORIES)

  const toggleShare = (id: string) => {
    setCategories(categories.map((cat) => (cat.id === id ? { ...cat, shared: !cat.shared } : cat)))
  }

  const sharedCount = categories.filter((c) => c.shared).length

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="px-4 py-6">
        {/* Header */}
        <View className="mb-6">
          <Text className="text-white text-2xl font-bold">Privacy Settings</Text>
          <Text className="text-gray-400 text-sm mt-2">Choose which spending categories your parents can see</Text>
        </View>

        {/* Sharing Summary */}
        <LinearGradient
          colors={["#1F2937", "#111827"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          className="rounded-lg p-4 mb-6 border border-primary/30"
        >
          <View className="flex-row justify-between items-center">
            <View>
              <Text className="text-gray-400 text-sm">Categories Shared</Text>
              <Text className="text-white text-2xl font-bold mt-1">
                {sharedCount}/{categories.length}
              </Text>
            </View>
            <Text className="text-4xl">🔒</Text>
          </View>
        </LinearGradient>

        {/* Category Toggles */}
        <View className="mb-6">
          <Text className="text-white font-bold text-lg mb-3">Spending Categories</Text>
          <FlatList
            scrollEnabled={false}
            data={categories}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View className="mb-3">
                <TouchableOpacity
                  onPress={() => toggleShare(item.id)}
                  className={`rounded-lg p-4 border flex-row justify-between items-center ${
                    item.shared ? "bg-dark-800 border-primary/30" : "bg-dark-900 border-dark-700"
                  }`}
                >
                  <View className="flex-row items-center flex-1">
                    <Text className="text-2xl mr-3">{item.icon}</Text>
                    <View className="flex-1">
                      <Text className="text-white font-semibold">{item.category}</Text>
                      <Text className="text-gray-400 text-xs">{item.description}</Text>
                    </View>
                  </View>
                  <Switch
                    value={item.shared}
                    onValueChange={() => toggleShare(item.id)}
                    trackColor={{ false: "#374151", true: "#16A34A" }}
                    thumbColor={item.shared ? "#22C55E" : "#6B7280"}
                  />
                </TouchableOpacity>

                {!item.shared && (
                  <View className="mt-2 rounded-lg overflow-hidden border border-dark-700">
                    <BlurView intensity={80}>
                      <View className="p-3 bg-dark-800/50 flex-row items-center">
                        <Text className="text-xl mr-2">🔐</Text>
                        <Text className="text-gray-400 text-xs flex-1">This category is hidden from parents</Text>
                      </View>
                    </BlurView>
                  </View>
                )}
              </View>
            )}
          />
        </View>

        {/* Info Box */}
        <LinearGradient
          colors={["#1F2937", "#111827"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          className="rounded-lg p-4 border border-warning/30"
        >
          <View className="flex-row">
            <Text className="text-2xl mr-3">ℹ️</Text>
            <View className="flex-1">
              <Text className="text-warning font-semibold text-sm mb-1">Privacy Note</Text>
              <Text className="text-gray-300 text-xs">
                Your parents can still see your total spending. Hidden categories won't appear in their detailed
                reports.
              </Text>
            </View>
          </View>
        </LinearGradient>
      </View>
    </ScrollView>
  )
}
