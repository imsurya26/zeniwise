"use client"

import type React from "react"
import { useState } from "react"
import { View, Text, TextInput, TouchableOpacity, ScrollView, ActivityIndicator } from "react-native"
import { useAuth } from "../context/AuthContext"

export const LoginScreen: React.FC = () => {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const { login, isLoading } = useAuth()

  const handleLogin = async () => {
    if (email && password) {
      await login(email, password)
    }
  }

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="flex-1 px-6 py-12 justify-center">
        {/* Header */}
        <View className="mb-12">
          <Text className="text-6xl mb-4">🌱</Text>
          <Text className="text-white text-3xl font-bold">Zeniwise</Text>
          <Text className="text-gray-400 text-base mt-2">AI-Powered Student Budget Planner</Text>
        </View>

        {/* Form */}
        <View className="gap-4 mb-8">
          <View>
            <Text className="text-gray-300 text-sm font-semibold mb-2">Email</Text>
            <TextInput
              className="bg-dark-800 text-white px-4 py-3 rounded-lg border border-dark-700"
              placeholder="your@email.com"
              placeholderTextColor="#6B7280"
              value={email}
              onChangeText={setEmail}
              editable={!isLoading}
            />
          </View>

          <View>
            <Text className="text-gray-300 text-sm font-semibold mb-2">Password</Text>
            <TextInput
              className="bg-dark-800 text-white px-4 py-3 rounded-lg border border-dark-700"
              placeholder="••••••••"
              placeholderTextColor="#6B7280"
              secureTextEntry
              value={password}
              onChangeText={setPassword}
              editable={!isLoading}
            />
          </View>
        </View>

        {/* Login Button */}
        <TouchableOpacity
          className="bg-primary py-3 rounded-lg mb-4 flex-row justify-center items-center"
          onPress={handleLogin}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text className="text-white font-bold text-base">Sign In</Text>
          )}
        </TouchableOpacity>

        {/* Google Sign-In */}
        <TouchableOpacity className="bg-dark-800 border border-dark-700 py-3 rounded-lg flex-row justify-center items-center">
          <Text className="text-2xl mr-2">🔵</Text>
          <Text className="text-white font-semibold">Sign in with Google</Text>
        </TouchableOpacity>

        {/* Footer */}
        <View className="mt-8 pt-8 border-t border-dark-700">
          <Text className="text-gray-400 text-xs text-center">
            By signing in, you agree to our Terms of Service and Privacy Policy
          </Text>
        </View>
      </View>
    </ScrollView>
  )
}
