import type React from "react"
import { Text } from "react-native"
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs"
import { createNativeStackNavigator } from "@react-navigation/native-stack"
import { HomeScreen } from "../screens/student/HomeScreen"
import { SavingsScreen } from "../screens/student/SavingsScreen"
import { RewardsScreen } from "../screens/student/RewardsScreen"
import { AnalyticsScreen } from "../screens/student/AnalyticsScreen"
import { ProfileScreen } from "../screens/student/ProfileScreen"
import { PrivacySettingsScreen } from "../screens/student/PrivacySettingsScreen"

const Tab = createBottomTabNavigator()
const Stack = createNativeStackNavigator()

const StudentTabs: React.FC = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: "#1F2937",
          borderTopColor: "#374151",
          borderTopWidth: 1,
        },
        tabBarActiveTintColor: "#16A34A",
        tabBarInactiveTintColor: "#6B7280",
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: "600",
        },
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarLabel: "Home",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>🏠</Text>,
        }}
      />
      <Tab.Screen
        name="Savings"
        component={SavingsScreen}
        options={{
          tabBarLabel: "Savings",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>💰</Text>,
        }}
      />
      <Tab.Screen
        name="Rewards"
        component={RewardsScreen}
        options={{
          tabBarLabel: "Rewards",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>🎁</Text>,
        }}
      />
      <Tab.Screen
        name="Analytics"
        component={AnalyticsScreen}
        options={{
          tabBarLabel: "Analytics",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>📊</Text>,
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarLabel: "Profile",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>👤</Text>,
        }}
      />
    </Tab.Navigator>
  )
}

export const StudentNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="StudentTabs" component={StudentTabs} />
      <Stack.Screen
        name="PrivacySettings"
        component={PrivacySettingsScreen}
        options={{
          headerShown: true,
          headerTitle: "Privacy Settings",
          headerStyle: {
            backgroundColor: "#0E1B14",
          },
          headerTintColor: "#16A34A",
          headerTitleStyle: {
            fontWeight: "bold",
            color: "#FFFFFF",
          },
        }}
      />
    </Stack.Navigator>
  )
}
