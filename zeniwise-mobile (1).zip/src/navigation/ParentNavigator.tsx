import type React from "react"
import { Text } from "react-native"
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs"
import { ParentDashboardScreen } from "../screens/parent/ParentDashboardScreen"
import { ParentAlertsScreen } from "../screens/parent/ParentAlertsScreen"
import { ParentSettingsScreen } from "../screens/parent/ParentSettingsScreen"

const Tab = createBottomTabNavigator()

export const ParentNavigator: React.FC = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: "#FDF6E3",
          borderTopColor: "#E5D5B8",
          borderTopWidth: 1,
        },
        tabBarActiveTintColor: "#16A34A",
        tabBarInactiveTintColor: "#9CA3AF",
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: "600",
        },
      }}
    >
      <Tab.Screen
        name="Overview"
        component={ParentDashboardScreen}
        options={{
          tabBarLabel: "Overview",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>📊</Text>,
        }}
      />
      <Tab.Screen
        name="Alerts"
        component={ParentAlertsScreen}
        options={{
          tabBarLabel: "Alerts",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>🔔</Text>,
        }}
      />
      <Tab.Screen
        name="Settings"
        component={ParentSettingsScreen}
        options={{
          tabBarLabel: "Settings",
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>⚙️</Text>,
        }}
      />
    </Tab.Navigator>
  )
}
